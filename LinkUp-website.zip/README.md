# LinkUp

A beginner-friendly social app starter inspired by chat/community apps and story-style sharing.

## Included
- Responsive UI for phone and desktop
- Friends list + search
- Local chat with automatic demo reply
- Stories stored in localStorage
- Call/video-call interface
- Theme toggle
- PWA manifest + service worker

## Important
This is a frontend starter. GitHub Pages can host it, but real accounts, multi-user messaging, notifications, file uploads and internet voice/video calls require a backend/database and WebRTC signaling.

## GitHub Pages
1. Create a public GitHub repository.
2. Upload `index.html`, `manifest.json`, and `sw.js`.
3. Repository Settings → Pages.
4. Under Build and deployment choose `Deploy from a branch`.
5. Select `main` and `/(root)`, then Save.
6. Open the generated `github.io` address.

## Free app option
Because this is a PWA, open the published site on Android Chrome and use the browser menu → Add to Home screen / Install app (wording can vary). This gives an app-like icon and standalone window without paying for a store listing.

Publishing on Google Play is different: Google Play has its own developer-account requirements and fees, so "free app" is best done as a PWA unless you specifically need Play Store distribution.
